﻿using StudentManagement.Business.Contracts;
using StudentManagement.Business.Dtos;
using StudentManagement.Web.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using StudentManagement.Business;

namespace StudentManagement.Web.Controllers
{
    public class AccountController : Controller
    {
        private IUserBusinessService userService;
        private IRoleBusinessService roleService;

        public AccountController(IUserBusinessService service)
        {
            userService = service;
        }

        //// GET: Account
        //public ActionResult Index()
        //{
        //    return View();
        //}

        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(RegistrationViewModel registerModel)
        {
            int us = 0;
          
            try
            {
                UserDto user = new UserDto();
                user.Username = registerModel.Username;
                user.Password = userService.EncodeSHA1(registerModel.Password);
                user.Phone = registerModel.Phone;
                user.Email = registerModel.Email;
                user.Address = registerModel.Address;
                user.Gender = registerModel.Gender;
                user.Image = registerModel.Image;
                user.IDRole = new Guid(us, 0, 0, new byte[8]);


                if (ModelState.IsValid)
                {
                    if (userService.checkUserName(registerModel.Username) == 0)
                    {
                        userService.InsertUser(user);
                        return Content("<script>alert('Successfully registered')</script>");
                    }
                    else
                    {
                        return Content("<script>alert('User name existed')</script>");
                    }
                }

            }
            catch (DataException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View();
        }

   
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginViewModel loginModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (userService.checkLogin(loginModel.Username, loginModel.Password) == 1)
                    {
                        FormsAuthentication.SetAuthCookie(loginModel.Username, loginModel.RememberMe);
                        return RedirectToAction("Index", "Home");
                        var users = userService.GetAllUsers();
                        foreach (var item in users)
                        {
                            if (loginModel.Username == item.Username)
                            {
                                ViewBag.UserID = item.ID;
                            }
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", "Login data is incorrect!");
                    }
                }

            }
            catch (DataException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View(loginModel);
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }
    }
}