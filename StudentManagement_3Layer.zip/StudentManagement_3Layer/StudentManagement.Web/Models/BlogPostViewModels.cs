﻿using StudentManagement.Business.Dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace StudentManagement.Web.Models
{
    public class CreatePostViewModels
    {
        [Required]
        [Display(Name = "Post Tiltle")]
        public string Title { get; set; }

        [Required]
        [DataType(DataType.MultilineText)]
        [Display(Name = "Post Content")]
        public string Content { get; set; }
       
      
    }

    public class BlogPostViewModels
    {
        
        public string Title { get; set; }

        
        public string Content { get; set; }

        public DateTime PostDate { get; set; }


    }
    public class ListPostViewModels
    {
        public List<BlogDto> BlogDto { get; set; }
    }
}